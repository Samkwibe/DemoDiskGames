﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoDisk
{
    public partial class PongGame : Form
    {

        int ballX = 5;
        int ballY = 5;
        int player1score = 0;
        int player2score = 0;
        int bounds;
        int centerX;
        int centerY;
        //int centerPoint;
        bool player1moveUp;
        bool player1moveDown;
        bool player2moveUp;
        bool player2moveDown;

        public PongGame()
        {
            InitializeComponent();
            bounds = ClientSize.Height - player1.Height; // sets paddle boundary
            bounds = ClientSize.Height - player2.Height;
            centerX = ClientSize.Width / 2; //sets integer value to middle of window on long side
            centerY = ClientSize.Height / 2; //wide side
        }

        private void PongGame_Load(object sender, EventArgs e)
        {

        }

        private void pongTimer_Tick(object sender, EventArgs e)
        {
            // int resetBall = 1;

            // sets the ball in motion diagonally
            ball.Top -= ballY;
            ball.Left -= ballX;


            // if the ball goes off to the left, recenters ball, sets it in the opposite direction, and adjusts score
            if (ball.Left < 0)
            {

                ball.Left = centerX;
                ball.Top = centerY;
                ballY = 5;
                ballX = 5;
                ballX = -ballX;
                player1score++;
                player1scoreLabel.Text = player1score.ToString();

            }

            // if the ball goes off to the right
            if (ball.Left + ball.Width > ClientSize.Width)
            {
                ball.Left = centerX;
                ball.Top = centerY;
                ballX = -ballX;
                player2score++;
                player2scoreLabel.Text = player2score.ToString();
                // pongTimer.Enabled = false;
            }

            // if top of ball is at the top of the window or the ball goes below the window, the ball will go in the opposite direction
            if (ball.Top < 0 || ball.Top + ball.Height > ClientSize.Height)
            {
                ballY = -ballY;
            }

            // if ball intersects with either paddle it sends ball in the other direction
            if (ball.Bounds.IntersectsWith(player1.Bounds) || ball.Bounds.IntersectsWith(player2.Bounds))
            {

                // sends ball in opposite direction

                ballX = -ballX;
                ballY++;
                ballX++;

            }

            // paddle movement
            if (player1moveUp == true && player1.Top > 0) { player1.Top -= 5; }

            if (player1moveDown == true && player1.Top < bounds) { player1.Top += 5; }

            if (player2moveUp == true && player2.Top > 0) { player2.Top -= 5; }

            if (player2moveDown == true && player2.Top < bounds) { player2.Top += 5; }

            if (player1score >= 10 || (player2score >= 10)) { pongTimer.Stop(); }

        }

        //checks keys pressed, moves paddles accordingly
        private void PongGame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) { player2moveUp = true; }
            if (e.KeyCode == Keys.Down) { player2moveDown = true; }
            if (e.KeyCode == Keys.W) { player1moveUp = true; }
            if (e.KeyCode == Keys.S) { player1moveDown = true; }
            if (e.KeyCode == Keys.M)
            {
                Form StartScreen = new Start_Screen();
                pongTimer.Stop();
            }
        }

        private void PongGame_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) { player2moveUp = false; }
            if (e.KeyCode == Keys.Down) { player2moveDown = false; }
            if (e.KeyCode == Keys.W) { player1moveUp = false; }
            if (e.KeyCode == Keys.S) { player1moveDown = false; }
        }

        private void player2_Click(object sender, EventArgs e)
        {

        }
    }
}
